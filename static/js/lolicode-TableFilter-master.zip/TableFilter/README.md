# LayUi组件：TableFilter

#### 项目介绍
表格列头过滤
#### 演示地址
[Demo](https://lolicode.gitee.io/tablefilter)
#### 功能
- 本地/服务端数据过滤
- 文本/单选/多选过滤类型
- 自动/自定义/AJAX过滤项
- 支持IE8